//
//  demoTools.cpp
//  EC_SDK_DEMO
//
//  Created by EC Open support team.
//  Copyright(C), 2018, Huawei Tech. Co., Ltd. ALL RIGHTS RESERVED.
//
#include "stdafx.h"
#include "demoTools.h"
#include<sstream>

using namespace std;

CTools::CTools(void)
{
}

CTools::~CTools(void)
{
}

wstring CTools::string2wstring(const string& str)
{
    //ȷ��ת��ΪUnicode��Ҫ���ٻ�����(����ֵҲ���������һ��NULL�ַ�)��
    int nLen = MultiByteToWideChar(CP_UTF8, 0, str.c_str(), -1, NULL, 0);

    if (0 >= (nLen + 1))
    {
        return L"";
    }
    wchar_t *pUnicode = new  wchar_t[nLen + 1];
    memset(pUnicode, 0, (nLen + 1)*sizeof(wchar_t));
    ::MultiByteToWideChar(CP_UTF8, 0, str.c_str(), -1, (LPWSTR)pUnicode, nLen);
    wstring  rt;
    rt = (wchar_t*)pUnicode;
    delete[] pUnicode;
    pUnicode = NULL;
    return rt;
}

CString CTools::UTF2UNICODE(const string& str)
{
    //ȷ��ת��ΪUnicode��Ҫ���ٻ�����(����ֵҲ���������һ��NULL�ַ�)��
    int nLen = MultiByteToWideChar(CP_UTF8, 0, str.c_str(), -1, NULL, 0);
    if (0 >= (nLen + 1))
    {
        return _T("");
    }
    wchar_t *pUnicode = new  wchar_t[nLen + 1];
    memset(pUnicode, 0, (nLen + 1)*sizeof(wchar_t));
    ::MultiByteToWideChar(CP_UTF8, 0, str.c_str(), -1, (LPWSTR)pUnicode, nLen);
    wstring  rt;
    rt = (wchar_t*)pUnicode;
    CString cstr(rt.c_str());
    delete[] pUnicode;
    pUnicode = NULL;
    return cstr;
}

string CTools::UNICODE2UTF(const CString& cstr)
{
    char* pElementText;
    int iTextLen;
    wstring wstr = (LPCWSTR)CStringW(cstr);;
    // wide char to multi char
    iTextLen = WideCharToMultiByte(CP_UTF8,
        0,
        wstr.c_str(),
        -1,
        NULL,
        0,
        NULL,
        NULL);
    if (0 >= (iTextLen + 1))
    {
        return "";
    }
    pElementText = new char[iTextLen + 1];
    memset((void*)pElementText, 0, sizeof(char) * (iTextLen + 1));
    ::WideCharToMultiByte(CP_UTF8,
        0,
        wstr.c_str(),
        -1,
        pElementText,
        iTextLen,
        NULL,
        NULL);
    string strText;
    strText = pElementText;
    delete[] pElementText;
    pElementText = NULL;
    return strText;
}

void CTools::CString2Char(const CString &str, char* ch, unsigned int lenth)
{
    string stdstr = UNICODE2UTF(str);
    strncpy_s(ch, lenth * sizeof(char), stdstr.c_str(), _TRUNCATE);
}
void CTools::string2CString(const string& str, CString& CStr)
{
    CStr = UTF2UNICODE(str);
}

int CTools::str2num(const string& str)
{
	return atoi(str.c_str());
}

string CTools::num2str(int i)
{
	char str[STRING_LENGTH] = { 0 };
	sprintf_s(str, STRING_LENGTH - 1, "%d", i);
	return string(str);
}

CString CTools::getCurrentPath()
{
	TCHAR tcPath[MAX_PATH];
	TCHAR tcFilename[MAX_PATH];
	TCHAR tcDrive[_MAX_DRIVE];
	TCHAR tcDir[_MAX_DIR];
	TCHAR tcFname[_MAX_FNAME];
	TCHAR tcExt[_MAX_EXT];

	(void)GetModuleFileName(NULL, tcFilename, _MAX_PATH);

	_tsplitpath_s(tcFilename, tcDrive, tcDir, tcFname, tcExt);
	_tcscpy_s(tcPath, tcDrive);
	_tcscat_s(tcPath, tcDir);

	CString strAppPath = tcPath;
	int nPos = strAppPath.ReverseFind(_T('\\'));
	strAppPath = strAppPath.Left(nPos);
	return strAppPath;
}

void CTools::writeIniConfigParam(const CString& sectionConfig, const CString& sectionName, const CString& sectionValue)
{
	CString serverParamPath = CTools::getCurrentPath() + _T("\\loginCfg.ini");
	(void)WritePrivateProfileString(sectionConfig, sectionName, sectionValue, serverParamPath);
}

void CTools::getIniConfigParam(const CString& sectionConfig, const CString& sectionName, CString& sectionValue)
{
	CString serverParamPath = CTools::getCurrentPath() + _T("\\loginCfg.ini");
	(void)GetPrivateProfileString(sectionConfig, sectionName, _T(""), sectionValue.GetBuffer(MAX_PATH), MAX_PATH, serverParamPath);
	sectionValue.ReleaseBuffer();
}

char* CTools::TCHAR2char(const TCHAR* STR)
{
	//�����ַ����ĳ���
	int size = WideCharToMultiByte(CP_ACP, 0, STR, -1, NULL, 0, NULL, FALSE);

	//����һ�����ֽڵ��ַ�������
	char* str = new char[sizeof(char) * size];

	//��STRת��str
	WideCharToMultiByte(CP_ACP, 0, STR, -1, str, size, NULL, FALSE);
	return str;
}


vector<string> CTools::split(string str, const char del)
{
	stringstream ss(str);
	string tok;
	vector<string> ret;
	while (getline(ss, tok, del))
	{
		if (tok > "")
		{
			ret.push_back(tok);
		}
	}
	return ret;
}