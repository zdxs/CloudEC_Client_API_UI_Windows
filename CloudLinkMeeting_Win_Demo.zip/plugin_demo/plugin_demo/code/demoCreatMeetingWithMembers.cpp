// demoCreatMeetingWithMembers.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "plugin_demo.h"
#include "demoCreatMeetingWithMembers.h"
#include "afxdialogex.h"
#include "demoTools.h"
#include "plugin_msg.h"
#include "plugin_interface.h"
#include "demoNotifyAndCallBackProc.h"

// demoCreatMeetingWithMembers �Ի���

IMPLEMENT_DYNAMIC(demoCreatMeetingWithMembers, CDialogEx)

demoCreatMeetingWithMembers::demoCreatMeetingWithMembers(CWnd* pParent /*=NULL*/)
	: CDialogEx(IDD_MEETING_CREAT_WITH_MEMBERS_DIALOG, pParent)
{

}

demoCreatMeetingWithMembers::~demoCreatMeetingWithMembers()
{
}

void demoCreatMeetingWithMembers::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_EDIT_CREAT_MEETING_WITH_MEMBERS_SUBJECT, m_meetingSubjectEdit);
	DDX_Control(pDX, IDC_COMBO_CREAT_MEETING_WITH_MEMBERS_TYPE, m_meetingTypeCombo);
	DDX_Control(pDX, IDC_EDIT_CREAT_MEETING_MEMBERS, m_meetingMembersEdit);
	DDX_Control(pDX, IDC_CHECK_NEED_PASSWORD_WITH_MEMBERS, m_needPasswordCheck);
}

BOOL demoCreatMeetingWithMembers::OnInitDialog()
{
	CDialog::OnInitDialog();

	m_meetingTypeCombo.InsertString(0, _T("Video"));
	m_meetingTypeCombo.InsertString(0, _T("Audio"));
	m_meetingTypeCombo.SetWindowText(_T("Video"));

	return TRUE;
}

BEGIN_MESSAGE_MAP(demoCreatMeetingWithMembers, CDialogEx)
	ON_BN_CLICKED(IDCANCEL, &demoCreatMeetingWithMembers::OnBnClickedCancel)
	ON_BN_CLICKED(IDOK, &demoCreatMeetingWithMembers::OnBnClickedOk)
END_MESSAGE_MAP()


// demoCreatMeetingWithMembers ��Ϣ��������

int demoCreatMeetingWithMembers::clickCreatMeetingWithMembers()
{
	struct plugin_create_meeting_with_participants_param data;
	memset(&data, 0, sizeof(plugin_create_meeting_with_participants_param));

	CString tempCString;
	string tempString;
	int length = 0;

	m_meetingSubjectEdit.GetWindowText(tempCString);
	tempString = CTools::UNICODE2UTF(tempCString);
	//������������
	if (tempString.length() > 0) 
	{
		length = tempString.length() + 1;
		char *meetingSubject;
		meetingSubject = (char *)malloc(sizeof(char) * length);
		strcpy_s(meetingSubject, length, tempString.c_str());
		data.meetingSubject = meetingSubject;
	}

	m_meetingTypeCombo.GetWindowText(tempCString);
	data.meetingType = 0;
	if (_T("Video") == tempCString)
	{
		data.meetingType = CONF_MEDIATYPE_FLAG_HDVIDEO_DATA;
	}
	else if (_T("Audio") == tempCString)
	{
		data.meetingType = CONF_MEDIATYPE_FLAG_VOICE_DATA;
	}

	data.needPassword = m_needPasswordCheck.GetCheck();

	m_meetingMembersEdit.GetWindowText(tempCString);
	tempString = CTools::UNICODE2UTF(tempCString);
	vector<string> list = CTools::split(tempString, ';');
	vector<string> temp;
	int count = list.size();
	meeting_participants *participants = NULL;
	int realCount = 0;
	if (count > 0)
	{
		participants = (meeting_participants *)malloc(sizeof(meeting_participants) * count);
		for (int i = 0; i < count; i++)
		{
			temp = CTools::split(list[i], '-');
			if (temp.size() == 2)
			{
				//����name
				char *name;
				length = temp[0].length() + 1;
				name = (char *)malloc(sizeof(char) * length);
				strcpy_s(name, length, temp[0].c_str());
				//����number
				char *number;
				length = temp[1].length() + 1;
				number = (char *)malloc(sizeof(char) * length);
				strcpy_s(number, length, temp[1].c_str());
				//���ṹ�帳ֵ
				participants[realCount].name = name;
				participants[realCount].number = number;
				//ָ�������1
				realCount++;
			}
		}
	}

	data.memberInfo.count = realCount;
	data.memberInfo.member = participants;

	//���ûص��ӿ�
	data.callbackFunc = demoNotifyAndCallBackProc::createMeetingCallBack;
	int ret = clm_createMeetingWithParticipants(&data);
	return ret;
}

void demoCreatMeetingWithMembers::OnBnClickedCancel()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CDialogEx::OnCancel();
}


void demoCreatMeetingWithMembers::OnBnClickedOk()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	int ret = clickCreatMeetingWithMembers();
	if (PLUGIN_STATUS_SUCCESS != ret)
	{
		AfxMessageBox(_T("Creat meeting with members error"));
		return;
	}
	CDialogEx::OnOK();
}
