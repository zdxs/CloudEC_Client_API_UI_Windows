// demoAddMeetingMemberDlg.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "plugin_demo.h"
#include "demoAddMeetingMemberDlg.h"
#include "afxdialogex.h"


// demoAddMeetingMemberDlg �Ի���

IMPLEMENT_DYNAMIC(demoAddMeetingMemberDlg, CDialogEx)

demoAddMeetingMemberDlg::demoAddMeetingMemberDlg(CWnd* pParent /*=NULL*/)
	: CDialogEx(IDD_MEETING_ADD_NUMBER_DIALOG, pParent)
{

}

demoAddMeetingMemberDlg::~demoAddMeetingMemberDlg()
{
}

void demoAddMeetingMemberDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_EDIT_NEW_MEMBER_NUMBER, m_addNumberEdit);
}


BEGIN_MESSAGE_MAP(demoAddMeetingMemberDlg, CDialogEx)
	ON_BN_CLICKED(IDCANCEL, &demoAddMeetingMemberDlg::OnBnClickedCancel)
	ON_BN_CLICKED(IDOK, &demoAddMeetingMemberDlg::OnBnClickedOk)
END_MESSAGE_MAP()


// demoAddMeetingMemberDlg ��Ϣ��������


void demoAddMeetingMemberDlg::OnBnClickedCancel()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CDialogEx::OnCancel();
}


void demoAddMeetingMemberDlg::OnBnClickedOk()
{
	m_addNumberEdit.GetWindowText(m_addNumber);
	CDialogEx::OnOK();
}
