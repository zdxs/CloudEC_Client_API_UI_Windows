#pragma once
#include "afxwin.h"
#include "afxcmn.h"
#include <vector>

// demoCreatMeetingDlg �Ի���

class demoCreatMeetingDlg : public CDialogEx
{
	DECLARE_DYNAMIC(demoCreatMeetingDlg)

public:
	demoCreatMeetingDlg(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~demoCreatMeetingDlg();

// �Ի�������
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_MEETING_CREAT_DIALOG };
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��
	virtual BOOL OnInitDialog();

	DECLARE_MESSAGE_MAP()
private:
	int clickCreatMeeting();
public:
	CEdit m_meetingSubjectEdit;
	CComboBox m_meetingTypeCombo;
	CButton m_needPasswordCheck;

	CString m_meetingSubject;
	afx_msg void OnBnClickedCancel();
	afx_msg void OnBnClickedOk();
};
