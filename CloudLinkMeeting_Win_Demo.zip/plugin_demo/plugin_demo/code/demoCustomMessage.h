//
//  demoCustomMessage.h
//  EC_SDK_DEMO
//
//  Created by EC Open support team.
//  Copyright(C), 2018, Huawei Tech. Co., Ltd. ALL RIGHTS RESERVED.
//

#ifndef __DEMO_CUSTOM_MESSAGE_H__
#define __DEMO_CUSTOM_MESSAGE_H__

using namespace std;

#ifdef __cplusplus
#if __cplusplus
extern "C" {
#endif
#endif /* __cplusplus */

#define DEMO_CUSTOM_BEGIN               WM_USER

#define CUSTOM_WM_BEGIN                 (DEMO_CUSTOM_BEGIN + 300)
//�ӿڻص�֪ͨ
#define WM_LOGIN_RESULT                 (CUSTOM_WM_BEGIN + 1)
#define WM_CREAT_MEETING_RESULT         (CUSTOM_WM_BEGIN + 2)
#define WM_JOIN_MEETING_RESULT          (CUSTOM_WM_BEGIN + 3)
#define WM_INIT_RESULT                  (CUSTOM_WM_BEGIN + 4)

//notify֪ͨ
#define WM_GET_NOTIFY                   (CUSTOM_WM_BEGIN + 500)

#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* __cplusplus */

#endif
