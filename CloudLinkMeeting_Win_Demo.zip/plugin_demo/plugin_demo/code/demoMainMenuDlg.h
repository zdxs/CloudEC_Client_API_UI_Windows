#pragma once
#include "afxcmn.h"

// demoMainMenuDlg �Ի���
#define ID_MEETING_RCLICK_MENU_1        (WM_USER + 1) 
#define ID_MEETING_RCLICK_MENU_10        (WM_USER + 10) 
class demoMainMenuDlg : public CDialogEx
{
	DECLARE_DYNAMIC(demoMainMenuDlg)

public:
	demoMainMenuDlg(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~demoMainMenuDlg();

// �Ի�������
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_MAIN_MENU_DIALOG };
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedButtonCreatInstantMeeting();
	afx_msg void OnBnClickedButtonJoinMeeting();
	afx_msg LRESULT demoMainMenuDlg::getNotify(WPARAM wParam, LPARAM lParam);
	afx_msg LRESULT createMeetingCallBack(WPARAM wParam, LPARAM lParam);
	afx_msg LRESULT joinMeetingCallBack(WPARAM wParam, LPARAM lParam);
	afx_msg void OnBnClickedButtonCreatMeetingWithMembers();
};
