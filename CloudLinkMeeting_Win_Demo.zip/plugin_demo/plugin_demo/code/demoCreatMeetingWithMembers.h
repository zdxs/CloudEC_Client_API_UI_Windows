#pragma once
#include "afxwin.h"


// demoCreatMeetingWithMembers �Ի���

class demoCreatMeetingWithMembers : public CDialogEx
{
	DECLARE_DYNAMIC(demoCreatMeetingWithMembers)

public:
	demoCreatMeetingWithMembers(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~demoCreatMeetingWithMembers();

// �Ի�������
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_MEETING_CREAT_WITH_MEMBERS_DIALOG };
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��
	virtual BOOL OnInitDialog();
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedCancel();
	afx_msg void OnBnClickedOk();
public:
	CEdit m_meetingSubjectEdit;
	CComboBox m_meetingTypeCombo;
	CEdit m_meetingMembersEdit;
	int clickCreatMeetingWithMembers();
	CButton m_needPasswordCheck;
};
