#pragma once
#include "afxwin.h"


// demoAddMeetingMemberDlg �Ի���

class demoAddMeetingMemberDlg : public CDialogEx
{
	DECLARE_DYNAMIC(demoAddMeetingMemberDlg)

public:
	demoAddMeetingMemberDlg(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~demoAddMeetingMemberDlg();

// �Ի�������
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_MEETING_ADD_NUMBER_DIALOG };
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

	DECLARE_MESSAGE_MAP()
public:
	CEdit m_addNumberEdit;
	CString m_addNumber;
	afx_msg void OnBnClickedCancel();
	afx_msg void OnBnClickedOk();
};
