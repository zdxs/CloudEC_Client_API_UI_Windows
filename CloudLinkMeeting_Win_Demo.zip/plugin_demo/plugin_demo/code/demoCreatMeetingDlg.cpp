// demoCreatMeetingDlg.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "plugin_demo.h"
#include "demoCreatMeetingDlg.h"
#include "afxdialogex.h"
#include "demoTools.h"
#include "plugin_msg.h"
#include "plugin_interface.h"
#include "demoAddMeetingMemberDlg.h"
#include "demoNotifyAndCallBackProc.h"

// demoCreatMeetingDlg �Ի���

IMPLEMENT_DYNAMIC(demoCreatMeetingDlg, CDialogEx)

demoCreatMeetingDlg::demoCreatMeetingDlg(CWnd* pParent /*=NULL*/)
	: CDialogEx(IDD_MEETING_CREAT_DIALOG, pParent)
{

}

demoCreatMeetingDlg::~demoCreatMeetingDlg()
{
}

void demoCreatMeetingDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_EDIT_CREAT_MEETING_SUBJECT, m_meetingSubjectEdit);
	DDX_Control(pDX, IDC_COMBO_CREAT_MEETING_TYPE, m_meetingTypeCombo);
	DDX_Control(pDX, IDC_RADIO_NEED_PASSWORD, m_needPasswordRadio);
}

BOOL demoCreatMeetingDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	m_meetingTypeCombo.InsertString(0, _T("Video"));
	m_meetingTypeCombo.SetWindowText(_T("Video"));

	return TRUE;
}

BEGIN_MESSAGE_MAP(demoCreatMeetingDlg, CDialogEx)
	ON_BN_CLICKED(IDOK, &demoCreatMeetingDlg::OnBnClickedOk)
	ON_BN_CLICKED(IDCANCEL, &demoCreatMeetingDlg::OnBnClickedCancel)
END_MESSAGE_MAP()


int demoCreatMeetingDlg::clickCreatMeeting()
{
	struct plugin_create_meeting_param data;
	memset(&data, 0, sizeof(plugin_create_meeting_param));

	m_meetingSubjectEdit.GetWindowText(m_meetingSubject);
	string meetingSubject = CTools::UNICODE2UTF(m_meetingSubject);
	strcpy_s(data.meetingSubject, MAX_INPUT_LENGTH + 1, meetingSubject.c_str());

	CString strMediaType;
	m_meetingTypeCombo.GetWindowText(strMediaType);
	data.meetingType = 0;
	//��ǰֻ֧��һ�ֻ�������
	if (_T("Video") == strMediaType)
	{
		data.meetingType = CONF_MEDIATYPE_FLAG_VIDEO_DATA;
	}

	data.needPassword = m_needPasswordRadio.GetCheck();

	//���ûص��ӿ�
	data.callbackFunc = demoNotifyAndCallBackProc::createMeetingCallBack;
	int ret = clm_createMeeting(&data);
	return ret;
}

void demoCreatMeetingDlg::OnBnClickedOk()
{
	int ret = clickCreatMeeting();
	if (PLUGIN_STATUS_SUCCESS != ret)
	{
		AfxMessageBox(_T("Creat meeting error"));
		return;
	}
	CDialogEx::OnOK();
}


void demoCreatMeetingDlg::OnBnClickedCancel()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CDialogEx::OnCancel();
}

