//
//  demoNotifyAndCallBackProc.h
//  EC_SDK_DEMO
//
//  Created by EC Open support team.
//  Copyright(C), 2018, Huawei Tech. Co., Ltd. ALL RIGHTS RESERVED.
//

#pragma once


class demoNotifyAndCallBackProc
{
private:
	demoNotifyAndCallBackProc(void);
    ~demoNotifyAndCallBackProc(void);
public:
	static void getNotify(int notifyId, void* data);
    static void loginCallBack(int ret, void* data);
	static void createMeetingCallBack(int ret, void* data);
	static void joinMeetingCallBack(int ret, void* data);
	static void initCallBack(int ret, void* data);
};
