
// plugin_demoDlg.h : ͷ�ļ�
//

#pragma once
#include "afxwin.h"

// Cplugin_demoDlg �Ի���
class Cplugin_demoDlg : public CDialogEx
{
// ����
public:
	Cplugin_demoDlg(CWnd* pParent = NULL);	// ��׼���캯��

// �Ի�������
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_PLUGIN_DEMO_DIALOG };
#endif

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV ֧��


// ʵ��
protected:
	HICON m_hIcon;

	// ���ɵ���Ϣӳ�亯��
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	DECLARE_MESSAGE_MAP()
public:
	CEdit m_serverIpEdit;
	CEdit m_serverPortEdit;
	CEdit m_loginAccountEdit;
	CEdit m_loginPwdEdit;
	CEdit m_meetingMenuCfgEdit;
	CString m_serverIp;
	CString m_serverPort;
	CString m_loginAccount;
	CString m_loginPwd;
	afx_msg void OnBnClickedButtonLogin();
	afx_msg LRESULT loginCallBack(WPARAM wParam, LPARAM lParam);
	afx_msg LRESULT initCallBack(WPARAM wParam, LPARAM lParam);
	static void exit();
private:
	int Login();
	int Init();
};
