#pragma once
#include "afxwin.h"


// demoJoinMeetingDlg �Ի���

class demoJoinMeetingDlg : public CDialogEx
{
	DECLARE_DYNAMIC(demoJoinMeetingDlg)

public:
	demoJoinMeetingDlg(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~demoJoinMeetingDlg();

// �Ի�������
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_MEETING_JOIN_BY_ID_DIALOG };
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

	DECLARE_MESSAGE_MAP()
public:
	CEdit m_meetingIDEdit;
	CEdit m_passwordEdit;
	CString m_meetingID;
	CString m_password;
	afx_msg void OnBnClickedCancel();
	afx_msg void OnBnClickedOk();
private:
	int demoJoinMeetingDlg::clickJoinMeetingById();
};
