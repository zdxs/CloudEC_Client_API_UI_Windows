//
//  demoTools.h
//  EC_SDK_DEMO
//
//  Created by EC Open support team.
//  Copyright(C), 2018, Huawei Tech. Co., Ltd. ALL RIGHTS RESERVED.
//

#pragma once

#include <string>
#include <afx.h>
#include <vector>

using namespace std;
const int STRING_LENGTH = 100;//���ж����ַ����̶�����
class CTools
{
private:
    CTools(void);
    ~CTools(void);
public:
    static CString UTF2UNICODE(const string& str);
    static wstring string2wstring(const string& str);
    static string UNICODE2UTF(const CString& cstr);
    static void CString2Char(const CString &str, char* ch, unsigned int lenth);
    static void string2CString(const string&, CString&);
	static int str2num(const string& str);
	static string CTools::num2str(int i);
	static void writeIniConfigParam(const CString& sectionConfig, const CString& sectionName, const CString& sectionValue);
	static CString getCurrentPath();
	static void getIniConfigParam(const CString& sectionConfig, const CString& sectionName, CString& sectionValue);
	static char* TCHAR2char(const TCHAR* STR);
	static vector<string> split(string str, const char del);
};
