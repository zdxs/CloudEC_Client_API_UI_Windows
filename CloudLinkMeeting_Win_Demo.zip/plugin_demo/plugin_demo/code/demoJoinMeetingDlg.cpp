// demoJoinMeetingDlg.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "plugin_demo.h"
#include "demoJoinMeetingDlg.h"
#include "afxdialogex.h"
#include "demoTools.h"
#include "plugin_msg.h"
#include "plugin_interface.h"
#include "demoNotifyAndCallBackProc.h"

// demoJoinMeetingDlg �Ի���

IMPLEMENT_DYNAMIC(demoJoinMeetingDlg, CDialogEx)

demoJoinMeetingDlg::demoJoinMeetingDlg(CWnd* pParent /*=NULL*/)
	: CDialogEx(IDD_MEETING_JOIN_BY_ID_DIALOG, pParent)
{

}

demoJoinMeetingDlg::~demoJoinMeetingDlg()
{
}

void demoJoinMeetingDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_EDIT_JOIN_MEETING_ID, m_meetingIDEdit);
	DDX_Control(pDX, IDC_EDIT_JOIN_MEETING_PASSWORD, m_passwordEdit);
}


BEGIN_MESSAGE_MAP(demoJoinMeetingDlg, CDialogEx)
	ON_BN_CLICKED(IDCANCEL, &demoJoinMeetingDlg::OnBnClickedCancel)
	ON_BN_CLICKED(IDOK, &demoJoinMeetingDlg::OnBnClickedOk)
END_MESSAGE_MAP()


// demoJoinMeetingDlg ��Ϣ��������


void demoJoinMeetingDlg::OnBnClickedCancel()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CDialogEx::OnCancel();
}

int demoJoinMeetingDlg::clickJoinMeetingById()
{
	m_meetingIDEdit.GetWindowText(m_meetingID);
	m_passwordEdit.GetWindowText(m_password);

	string meetingID = CTools::UNICODE2UTF(m_meetingID);
	string password = CTools::UNICODE2UTF(m_password);

	struct plugin_join_meeting_by_id_param data;
	memset(&data, 0, sizeof(plugin_join_meeting_by_id_param));

	strcpy_s(data.meetingID, MAX_INPUT_LENGTH + 1, meetingID.c_str());
	strcpy_s(data.password, MAX_INPUT_LENGTH + 1, password.c_str());

	//���ûص��ӿ�
	data.callbackFunc = demoNotifyAndCallBackProc::joinMeetingCallBack;
	int ret = clm_joinMeetingById(&data);
	return ret;
}

void demoJoinMeetingDlg::OnBnClickedOk()
{
	int ret = clickJoinMeetingById();
	if (PLUGIN_STATUS_SUCCESS != ret)
	{
		AfxMessageBox(_T("Join meeting error"));
		return;
	}
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CDialogEx::OnOK();
}
