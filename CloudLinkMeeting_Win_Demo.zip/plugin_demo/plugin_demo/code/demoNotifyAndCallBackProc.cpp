//
//  demoNotifyAndCallBackProc.cpp
//  EC_SDK_DEMO
//
//  Created by EC Open support team.
//  Copyright(C), 2018, Huawei Tech. Co., Ltd. ALL RIGHTS RESERVED.
//

#include "stdafx.h"
#include <string>
#include "demoNotifyAndCallBackProc.h"
#include "plugin_demo.h"
#include "plugin_demoDlg.h"
#include "demoCustomMessage.h"
#include "demoMainMenuDlg.h"
#include "plugin_notify.h"

demoNotifyAndCallBackProc::demoNotifyAndCallBackProc(void)
{
}

demoNotifyAndCallBackProc::~demoNotifyAndCallBackProc(void)
{
}

/**
* notify��Ϣ֪ͨ
*/
void demoNotifyAndCallBackProc::getNotify(int notifyId, void* data)
{
	Cplugin_demoApp* app = (Cplugin_demoApp*)AfxGetApp();
	if (!app)
	{
		//�����Ѿ��ر�
		return;
	}
	demoMainMenuDlg* dlg = (demoMainMenuDlg*)(app->m_pCurDlgWnd);
	if (!dlg)
	{
		return;
	}
	if (data != NULL)
	{
		switch (notifyId) {
			//�Բ�ͬnotify�����ڴ棬ʹ�ú�������
			case PLUGIN_NOTIFY_USER_WAS_KICKED_OUT: {
				void* result = (void*)malloc(sizeof(plugin_notify_common_result));
				if (result != NULL)
				{
					memcpy_s(result, sizeof(plugin_notify_common_result), data, sizeof(plugin_notify_common_result));
					::PostMessage(dlg->GetSafeHwnd(), WM_GET_NOTIFY, (LPARAM)notifyId, (WPARAM)result);
				}
				break;
			}
			//�Բ�ͬnotify�����ڴ棬ʹ�ú�������
			case PLUGIN_NOTIFY_CUSTOM_MENU_CLICK: {
				void* result = (void*)malloc(sizeof(plugin_notify_custom_menu_click));
				if (result != NULL)
				{
					memcpy_s(result, sizeof(plugin_notify_custom_menu_click), data, sizeof(plugin_notify_custom_menu_click));
					::PostMessage(dlg->GetSafeHwnd(), WM_GET_NOTIFY, (LPARAM)notifyId, (WPARAM)result);
				}
				break;
			}
			case PLUGIN_NOTIFY_DATA_SHARING_STATE_CHANGED: {
				void* result = (void*)malloc(sizeof(plugin_notify_data_sharing_state_changed));
				if (result != NULL)
				{
					memcpy_s(result, sizeof(plugin_notify_data_sharing_state_changed), data, sizeof(plugin_notify_data_sharing_state_changed));
					::PostMessage(dlg->GetSafeHwnd(), WM_GET_NOTIFY, (LPARAM)notifyId, (WPARAM)result);
				}
				break;
			}
			case PLUGIN_NOTIFY_DATA_SHARING_PERSON_CHANGED: {
				void* result = (void*)malloc(sizeof(plugin_notify_data_sharing_person_changed));
				if (result != NULL)
				{
					memcpy_s(result, sizeof(plugin_notify_data_sharing_person_changed), data, sizeof(plugin_notify_data_sharing_person_changed));
					::PostMessage(dlg->GetSafeHwnd(), WM_GET_NOTIFY, (LPARAM)notifyId, (WPARAM)result);
				}
				break;
			}
			case PLUGIN_NOTIFY_CONF_INFO: {
				void* result = (void*)malloc(sizeof(plugin_notify_conf_info));
				if (result != NULL)
				{
					memcpy_s(result, sizeof(plugin_notify_conf_info), data, sizeof(plugin_notify_conf_info));
					::PostMessage(dlg->GetSafeHwnd(), WM_GET_NOTIFY, (LPARAM)notifyId, (WPARAM)result);
				}
				break;
			}
			case PLUGIN_NOTIFY_CONF_LIFECYCLE: {
				void* result = (void*)malloc(sizeof(plugin_notify_conf_lifecycle));
				if (result != NULL)
				{
					memcpy_s(result, sizeof(plugin_notify_conf_lifecycle), data, sizeof(plugin_notify_conf_lifecycle));
					::PostMessage(dlg->GetSafeHwnd(), WM_GET_NOTIFY, (LPARAM)notifyId, (WPARAM)result);
				}
				break;
			}
			case PLUGIN_NOTIFY_GET_REMOTE_CONTROL_PRIVLEGE: {
				void* result = (void*)malloc(sizeof(plugin_notify_get_remote_control_privlege));
				if (result != NULL)
				{
					memcpy_s(result, sizeof(plugin_notify_get_remote_control_privlege), data, sizeof(plugin_notify_get_remote_control_privlege));
					::PostMessage(dlg->GetSafeHwnd(), WM_GET_NOTIFY, (LPARAM)notifyId, (WPARAM)result);
				}
				break;
			}
			case PLUGIN_NOTIFY_DEL_REMOTE_CONTROL_PRIVLEGE: {
				void* result = (void*)malloc(sizeof(plugin_notify_del_remote_control_privlege));
				if (result != NULL)
				{
					memcpy_s(result, sizeof(plugin_notify_del_remote_control_privlege), data, sizeof(plugin_notify_del_remote_control_privlege));
					::PostMessage(dlg->GetSafeHwnd(), WM_GET_NOTIFY, (LPARAM)notifyId, (WPARAM)result);
				}
				break;
			}
			case PLUGIN_NOTIFY_DATA_SHARING_HWND_INFO: {
				void* result = (void*)malloc(sizeof(plugin_notify_data_sharing_hwnd_info));
				if (result != NULL)
				{
					memcpy_s(result, sizeof(plugin_notify_data_sharing_hwnd_info), data, sizeof(plugin_notify_data_sharing_hwnd_info));
					::PostMessage(dlg->GetSafeHwnd(), WM_GET_NOTIFY, (LPARAM)notifyId, (WPARAM)result);
				}
				break;
			}
			default:
			{
				break;
			}
		}
	}
}

/**
* ��ʼ������ص�
* ��ע����ǰdataδʹ�ã���Ҫʹ���������ڴ汣�����ݣ�ʹ�ú��ͷ�
*/
void demoNotifyAndCallBackProc::initCallBack(int ret, void* data)
{
	Cplugin_demoApp* app = (Cplugin_demoApp*)AfxGetApp();
	if (!app)
	{
		//�����Ѿ��ر�
		return;
	}
	Cplugin_demoDlg* logindlg = (Cplugin_demoDlg*)(app->m_pCurDlgWnd);
	if (!logindlg)
	{
		return;
	}
	::PostMessage(logindlg->GetSafeHwnd(), WM_INIT_RESULT, (LPARAM)ret, (WPARAM)data);
}


/**
 * ��¼����ص�
 * ��ע����ǰdataδʹ�ã���Ҫʹ���������ڴ汣�����ݣ�ʹ�ú��ͷ�
 */
void demoNotifyAndCallBackProc::loginCallBack(int ret, void* data)
{
	Cplugin_demoApp* app = (Cplugin_demoApp*)AfxGetApp();
    if (!app)
    {
        //�����Ѿ��ر�
        return;
    }
	Cplugin_demoDlg* logindlg = (Cplugin_demoDlg*)(app->m_pCurDlgWnd);
	if (!logindlg)
	{
		return;
	}
	::PostMessage(logindlg->GetSafeHwnd(), WM_LOGIN_RESULT, (LPARAM)ret, (WPARAM)data);
}

/**
 * �������ص�
 * ��ע����ǰdataδʹ�ã���Ҫʹ���������ڴ汣�����ݣ�ʹ�ú��ͷ�
 */
void demoNotifyAndCallBackProc::createMeetingCallBack(int ret, void* data)
{
	Cplugin_demoApp* app = (Cplugin_demoApp*)AfxGetApp();
	if (!app)
	{
		//�����Ѿ��ر�
		return;
	}
	demoMainMenuDlg* dlg = (demoMainMenuDlg*)(app->m_pCurDlgWnd);
	if (!dlg)
	{
		return;
	}
	::PostMessage(dlg->GetSafeHwnd(), WM_CREAT_MEETING_RESULT, (LPARAM)ret, (WPARAM)data);
}

/**
 * ����������ص�
 * ��ע����ǰdataδʹ�ã���Ҫʹ���������ڴ汣�����ݣ�ʹ�ú��ͷ�
 */
void demoNotifyAndCallBackProc::joinMeetingCallBack(int ret, void* data)
{
	Cplugin_demoApp* app = (Cplugin_demoApp*)AfxGetApp();
	if (!app)
	{
		//�����Ѿ��ر�
		return;
	}
	demoMainMenuDlg* dlg = (demoMainMenuDlg*)(app->m_pCurDlgWnd);
	if (!dlg)
	{
		return;
	}
	::PostMessage(dlg->GetSafeHwnd(), WM_JOIN_MEETING_RESULT, (LPARAM)ret, (WPARAM)data);
}
