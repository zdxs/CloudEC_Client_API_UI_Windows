//
//  demoNotifyAndCallBackProc.cpp
//  EC_SDK_DEMO
//
//  Created by EC Open support team.
//  Copyright(C), 2018, Huawei Tech. Co., Ltd. ALL RIGHTS RESERVED.
//

#include "stdafx.h"
#include <string>
#include "demoNotifyAndCallBackProc.h"
#include "plugin_demo.h"
#include "plugin_demoDlg.h"
#include "demoCustomMessage.h"
#include "demoMainMenuDlg.h"
#include "demoJoinMeetingDlg.h"

demoNotifyAndCallBackProc::demoNotifyAndCallBackProc(void)
{
}

demoNotifyAndCallBackProc::~demoNotifyAndCallBackProc(void)
{
}

/**
* notify��Ϣ֪ͨ
*/
void demoNotifyAndCallBackProc::getNotify(int notifyId, void* data)
{
	Cplugin_demoApp* app = (Cplugin_demoApp*)AfxGetApp();
	if (!app)
	{
		//�����Ѿ��ر�
		return;
	}
	demoJoinMeetingDlg* dlg = (demoJoinMeetingDlg*)(app->m_pMainWnd);
	::PostMessage(dlg->GetSafeHwnd(), WM_GET_NOTIFY, (LPARAM)notifyId, (WPARAM)data);
}

/**
* ��ʼ������ص�
*/
void demoNotifyAndCallBackProc::initCallBack(int ret, void* data)
{
	Cplugin_demoApp* app = (Cplugin_demoApp*)AfxGetApp();
	if (!app)
	{
		//�����Ѿ��ر�
		return;
	}
	Cplugin_demoDlg* logindlg = (Cplugin_demoDlg*)(app->m_pLoginDlgWnd);
	::PostMessage(logindlg->GetSafeHwnd(), WM_INIT_RESULT, (LPARAM)ret, (WPARAM)data);
}


/**
 * ��¼����ص�
 */
void demoNotifyAndCallBackProc::loginCallBack(int ret, void* data)
{
	Cplugin_demoApp* app = (Cplugin_demoApp*)AfxGetApp();
    if (!app)
    {
        //�����Ѿ��ر�
        return;
    }
	Cplugin_demoDlg* logindlg = (Cplugin_demoDlg*)(app->m_pLoginDlgWnd);
	::PostMessage(logindlg->GetSafeHwnd(), WM_LOGIN_RESULT, (LPARAM)ret, (WPARAM)data);
}

/**
 * �������ص�
 */
void demoNotifyAndCallBackProc::createMeetingCallBack(int ret, void* data)
{
	Cplugin_demoApp* app = (Cplugin_demoApp*)AfxGetApp();
	if (!app)
	{
		//�����Ѿ��ر�
		return;
	}
	demoMainMenuDlg* dlg = (demoMainMenuDlg*)(app->m_pMainWnd);
	::PostMessage(dlg->GetSafeHwnd(), WM_CREAT_MEETING_RESULT, (LPARAM)ret, (WPARAM)data);
}

/**
 * ����������ص�
 */
void demoNotifyAndCallBackProc::joinMeetingCallBack(int ret, void* data)
{
	Cplugin_demoApp* app = (Cplugin_demoApp*)AfxGetApp();
	if (!app)
	{
		//�����Ѿ��ر�
		return;
	}
	demoJoinMeetingDlg* dlg = (demoJoinMeetingDlg*)(app->m_pMainWnd);
	::PostMessage(dlg->GetSafeHwnd(), WM_JOIN_MEETING_RESULT, (LPARAM)ret, (WPARAM)data);
}
