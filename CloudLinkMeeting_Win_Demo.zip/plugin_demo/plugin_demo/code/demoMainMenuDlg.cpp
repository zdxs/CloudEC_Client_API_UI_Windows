// demoMainMenuDlg.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include <map>
#include <tchar.h>
#include "plugin_demo.h"
#include "afxdialogex.h"
#include "demoMainMenuDlg.h"
#include "demoJoinMeetingDlg.h"
#include "demoCreatMeetingDlg.h"
#include "plugin_msg.h"
#include "demoCustomMessage.h"
#include "demoNotifyAndCallBackProc.h"
#include "plugin_interface.h"
#include "demoTools.h"
#include "demoCreatMeetingWithMembers.h"
#include "plugin_notify.h"

// demoMainMenuDlg �Ի���

IMPLEMENT_DYNAMIC(demoMainMenuDlg, CDialogEx)

demoMainMenuDlg::demoMainMenuDlg(CWnd* pParent /*=NULL*/)
	: CDialogEx(IDD_MAIN_MENU_DIALOG, pParent)
{

}

demoMainMenuDlg::~demoMainMenuDlg()
{
}

void demoMainMenuDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(demoMainMenuDlg, CDialogEx)
	ON_MESSAGE(WM_GET_NOTIFY, &demoMainMenuDlg::getNotify)
	ON_MESSAGE(WM_CREAT_MEETING_RESULT, &demoMainMenuDlg::createMeetingCallBack)
	ON_MESSAGE(WM_JOIN_MEETING_RESULT, &demoMainMenuDlg::joinMeetingCallBack)

	ON_BN_CLICKED(IDC_BUTTON_CREAT_INSTANT_MEETING, &demoMainMenuDlg::OnBnClickedButtonCreatInstantMeeting)
	ON_BN_CLICKED(IDC_BUTTON_JOIN_MEETING, &demoMainMenuDlg::OnBnClickedButtonJoinMeeting)
	ON_BN_CLICKED(IDC_BUTTON_CREAT_MEETING_WITH_MEMBERS, &demoMainMenuDlg::OnBnClickedButtonCreatMeetingWithMembers)
END_MESSAGE_MAP()

// demoMainMenuDlg ��Ϣ��������

afx_msg LRESULT demoMainMenuDlg::getNotify(WPARAM wParam, LPARAM lParam)
{
	int id = (int)wParam;
	CString strNotifyId;
	strNotifyId.Format(_T("%d"), id);
	switch (id) {
		case PLUGIN_NOTIFY_CUSTOM_MENU_CLICK: {
			plugin_notify_custom_menu_click  *parm = (plugin_notify_custom_menu_click *)lParam;
			if (parm != NULL)
			{
				CString strMenuType;
				strMenuType.Format(_T("%d"), parm->menuType);

				CString strMenuKey = CString(parm->menuKey);

				CString strMenuIndex;
				strMenuIndex.Format(_T("%d"), parm->menuIndex);

				CString strMenuName = CString(parm->menuName);

				CString strSrc = _T("�¼�ID:") + strNotifyId  + _T(", menuTpye:") + strMenuType + _T(", menuKey:") + strMenuKey + _T(", menuIndex:") + strMenuIndex + _T(", menuName:") + strMenuName;
				AfxMessageBox(strSrc);
				//ʹ�����ͷ��ڴ�
				free(parm);
				parm = NULL;
			}

			break;
		}
		case PLUGIN_NOTIFY_DATA_SHARING_STATE_CHANGED: {
			plugin_notify_data_sharing_state_changed  *parm = (plugin_notify_data_sharing_state_changed *)lParam;
			if (parm != NULL)
			{
				CString strStatus;
				strStatus.Format(_T("%d"), parm->shareStatus);

				CString strSrc = _T("�¼�ID:") + strNotifyId + _T(", ����״̬:") + strStatus;
				AfxMessageBox(strSrc);
				free(parm);
				parm = NULL;
			}

			break;
		}
		case PLUGIN_NOTIFY_DATA_SHARING_PERSON_CHANGED: {
			plugin_notify_data_sharing_person_changed  *parm = (plugin_notify_data_sharing_person_changed *)lParam;
			if (parm != NULL)
			{
				CString strSharerName = CString(parm->sharerName);

				CString strSrc = _T("�¼�ID:") + strNotifyId + _T(", ��ǰ������:") + strSharerName;
				AfxMessageBox(strSrc);
				free(parm);
				parm = NULL;
			}

			break;
		}
		case PLUGIN_NOTIFY_USER_WAS_KICKED_OUT: {
			//�û�����ʱ�˳�Ӧ��
			int ret = clm_exit_sync();
			//��ȡ���ص�����
			plugin_notify_common_result* result = (plugin_notify_common_result*)lParam;
			if (result != NULL)
			{
				CString cMsg = CString(result->msg);
				CString cCode;
				cCode.Format(_T("%d"), result->code);
				AfxMessageBox(cMsg + _T("������ֵ:") + cCode);
				//ʹ�����ͷ��ڴ�
				free(result);
				result = NULL;
			}
			else
			{
				AfxMessageBox(_T("Account has been kicked out"));
			}
			//�ص���¼����
			OnOK();
			break;
		}
		default:
			break;
	}
	return 0L;
}

afx_msg LRESULT demoMainMenuDlg::createMeetingCallBack(WPARAM wParam, LPARAM lParam)
{
	if (wParam != PLUGIN_STATUS_SUCCESS)
	{
		AfxMessageBox(_T("Creat Meeting Failed"));
	}
	else
	{
		AfxMessageBox(_T("Creat Meeting Success"));
	}
	return 0L;
}

afx_msg LRESULT demoMainMenuDlg::joinMeetingCallBack(WPARAM wParam, LPARAM lParam)
{
	if (wParam != PLUGIN_STATUS_SUCCESS)
	{
		AfxMessageBox(_T("Join Meeting Failed"));
	}
	else
	{
		AfxMessageBox(_T("Join Meeting Success"));
	}
	return 0L;
}

void demoMainMenuDlg::OnBnClickedButtonCreatInstantMeeting()
{
	//�򿪴��ᴰ��
	demoCreatMeetingDlg dlg;
	INT_PTR nResponse = dlg.DoModal();
}

void demoMainMenuDlg::OnBnClickedButtonJoinMeeting()
{
	//�򿪻���ID��ᴰ��
	demoJoinMeetingDlg dlg;
	INT_PTR nResponse = dlg.DoModal();
}


void demoMainMenuDlg::OnBnClickedButtonCreatMeetingWithMembers()
{
	//�򿪴��ᴰ�ڣ�������ߣ�
	demoCreatMeetingWithMembers dlg;
	INT_PTR nResponse = dlg.DoModal();
}
