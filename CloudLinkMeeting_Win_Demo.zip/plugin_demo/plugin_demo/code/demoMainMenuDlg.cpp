// demoMainMenuDlg.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include <map>
#include <tchar.h>
#include "plugin_demo.h"
#include "afxdialogex.h"
#include "demoMainMenuDlg.h"
#include "demoJoinMeetingDlg.h"
#include "demoCreatMeetingDlg.h"
#include "plugin_msg.h"
#include "demoCustomMessage.h"
#include "demoNotifyAndCallBackProc.h"
#include "plugin_interface.h"
#include "demoTools.h"
#include "demoCreatMeetingWithMembers.h"

// demoMainMenuDlg �Ի���

IMPLEMENT_DYNAMIC(demoMainMenuDlg, CDialogEx)

demoMainMenuDlg::demoMainMenuDlg(CWnd* pParent /*=NULL*/)
	: CDialogEx(IDD_MAIN_MENU_DIALOG, pParent)
{

}

demoMainMenuDlg::~demoMainMenuDlg()
{
}

void demoMainMenuDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(demoMainMenuDlg, CDialogEx)
	ON_MESSAGE(WM_GET_NOTIFY, &demoMainMenuDlg::getNotify)
	ON_MESSAGE(WM_CREAT_MEETING_RESULT, &demoMainMenuDlg::createMeetingCallBack)
	ON_MESSAGE(WM_JOIN_MEETING_RESULT, &demoMainMenuDlg::joinMeetingCallBack)

	ON_BN_CLICKED(IDC_BUTTON_CREAT_INSTANT_MEETING, &demoMainMenuDlg::OnBnClickedButtonCreatInstantMeeting)
	ON_BN_CLICKED(IDC_BUTTON_JOIN_MEETING, &demoMainMenuDlg::OnBnClickedButtonJoinMeeting)
	ON_BN_CLICKED(IDC_BUTTON_CREAT_MEETING_WITH_MEMBERS, &demoMainMenuDlg::OnBnClickedButtonCreatMeetingWithMembers)
END_MESSAGE_MAP()

// demoMainMenuDlg ��Ϣ��������

afx_msg LRESULT demoMainMenuDlg::getNotify(WPARAM wParam, LPARAM lParam)
{
	/*��ǰ�޻ص�֪ͨ*/
	return 0L;
}

afx_msg LRESULT demoMainMenuDlg::createMeetingCallBack(WPARAM wParam, LPARAM lParam)
{
	if (wParam != PLUGIN_STATUS_SUCCESS)
	{
		AfxMessageBox(_T("Creat Meeting Failed"));
	}
	else
	{
		AfxMessageBox(_T("Creat Meeting Success"));
	}
	return 0L;
}

afx_msg LRESULT demoMainMenuDlg::joinMeetingCallBack(WPARAM wParam, LPARAM lParam)
{
	if (wParam != PLUGIN_STATUS_SUCCESS)
	{
		AfxMessageBox(_T("Join Meeting Failed"));
	}
	else
	{
		AfxMessageBox(_T("Join Meeting Success"));
	}
	return 0L;
}

void demoMainMenuDlg::OnBnClickedButtonCreatInstantMeeting()
{
	//�򿪴��ᴰ��
	demoCreatMeetingDlg dlg;
	INT_PTR nResponse = dlg.DoModal();
}

void demoMainMenuDlg::OnBnClickedButtonJoinMeeting()
{
	//�򿪻���ID��ᴰ��
	demoJoinMeetingDlg dlg;
	INT_PTR nResponse = dlg.DoModal();
}


void demoMainMenuDlg::OnBnClickedButtonCreatMeetingWithMembers()
{
	//�򿪴��ᴰ�ڣ�������ߣ�
	demoCreatMeetingWithMembers dlg;
	INT_PTR nResponse = dlg.DoModal();
}
