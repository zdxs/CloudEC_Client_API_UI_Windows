#pragma once


// joinTempMeetingDlg �Ի���

class joinTempMeetingDlg : public CDialogEx
{
	DECLARE_DYNAMIC(joinTempMeetingDlg)

public:
	joinTempMeetingDlg(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~joinTempMeetingDlg();

// �Ի�������
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_JOIN_TEMP_MEETING_DIALOG };
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��
	virtual BOOL OnInitDialog();
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedButtonJoinTempMeeting();
	CEdit m_serverAddress;
	CEdit m_serverPort;
	CEdit m_meetingID;
	CEdit m_meetingPassword;
	CEdit m_showName;
	CButton m_openMic;
	CButton m_openCam;
};
