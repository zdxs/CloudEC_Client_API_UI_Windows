// joinTempMeetingDlg.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "scheme_demo.h"
#include "joinTempMeetingDlg.h"
#include "afxdialogex.h"


// joinTempMeetingDlg �Ի���

IMPLEMENT_DYNAMIC(joinTempMeetingDlg, CDialogEx)

joinTempMeetingDlg::joinTempMeetingDlg(CWnd* pParent /*=NULL*/)
	: CDialogEx(IDD_JOIN_TEMP_MEETING_DIALOG, pParent)
{

}

joinTempMeetingDlg::~joinTempMeetingDlg()
{
}

void joinTempMeetingDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_EDIT_SERVER_ADDRESS, m_serverAddress);
	DDX_Control(pDX, IDC_EDIT_SERVER_PORT, m_serverPort);
	DDX_Control(pDX, IDC_EDIT_MEETING_ID, m_meetingID);
	DDX_Control(pDX, IDC_EDIT_PASSWORD, m_meetingPassword);
	DDX_Control(pDX, IDC_EDIT_SHOW_NAME, m_showName);
	DDX_Control(pDX, IDC_CHECK_OPEN_MIC, m_openMic);
	DDX_Control(pDX, IDC_CHECK_OPEN_CAM, m_openCam);
}


BEGIN_MESSAGE_MAP(joinTempMeetingDlg, CDialogEx)
	ON_BN_CLICKED(IDC_BUTTON_JOIN_TEMP_MEETING, &joinTempMeetingDlg::OnBnClickedButtonJoinTempMeeting)
END_MESSAGE_MAP()

BOOL joinTempMeetingDlg::OnInitDialog()
{
	CDialog::OnInitDialog();
	//��ʼ������ͷ��˷�Ϊѡ��״̬
	m_openMic.SetCheck(1);
	m_openCam.SetCheck(1);
	m_serverAddress.SetWindowText(_T("cloudec.huaweicloud.com"));
	m_serverPort.SetWindowText(_T("8443"));

	return TRUE;
}
// joinTempMeetingDlg ��Ϣ��������

//�����ᰴť�����ӿ�
void joinTempMeetingDlg::OnBnClickedButtonJoinTempMeeting()
{
	//�Ӵ��ڻ�ȡ�û�����
	CString serverAddress;
	CString serverPort;
	CString meetingID;
	CString meetingPassword;
	CString showName;
	int openMic = 0;
	int openCam = 0;
	m_serverAddress.GetWindowText(serverAddress);
	m_serverPort.GetWindowText(serverPort);
	m_meetingID.GetWindowText(meetingID);
	m_meetingPassword.GetWindowText(meetingPassword);
	m_showName.GetWindowText(showName);
	openMic = m_openMic.GetCheck();
	openCam = m_openCam.GetCheck();

	CString isOpenMic = (openMic == 0) ? _T("false") : _T("true");
	CString isOpenCam = (openCam == 0) ? _T("false") : _T("true");
	//��װscheme
	CString schemeStr = _T("cloudlink://welinksoftclient/h5page?page=joinConfByLink&server_url=")
		+ serverAddress + _T("&port=")
		+ serverPort + _T("&conf_id=")
		+ meetingID + _T("&enter_code=")
		+ meetingPassword + _T("&name=")
		+ showName + _T("&open_mic=")
		+ isOpenMic + _T("&open_camera=")
		+ isOpenCam;

	HWND hwnd = AfxGetApp()->GetMainWnd()->GetSafeHwnd();
	ShellExecute(hwnd, _T("open"), schemeStr, NULL, NULL, SW_SHOWNORMAL);
	CDialogEx::OnOK();
}
